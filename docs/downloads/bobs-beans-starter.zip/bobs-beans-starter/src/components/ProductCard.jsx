// ═══════════════════════════════════════════════════════════════════════════
//  LAB 02 — Build the product card.   It appears in the grid on  mockups/home.png
//
//  Props:  { product }   — a Product object (see the typedef in ../api/client.js)
//
//  It should show: the product image, category, name, price, and an add (+)
//  button, and link to  /product/:id.  Use  imageUrl(product.image)  from
//  ../api/client to build the <img> src, and  useCart()  if you want the +
//  button to add to the cart.
//
//  This is a stub so the app compiles. Replace it with your real card.
// ═══════════════════════════════════════════════════════════════════════════

export default function ProductCard({ product }) {
  return (
    <div className="rounded-card border border-dashed border-line bg-white p-4 text-sm text-muted shadow-card">
      Product card for <strong className="text-ink">{product?.name ?? "?"}</strong> — build me in Lab 02.
    </div>
  );
}
