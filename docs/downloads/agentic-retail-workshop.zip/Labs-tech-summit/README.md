# Labs Tech Summit

Laboratorios prácticos que integran **Confluent Kafka**, **IBM watsonx Orchestrate** y **React** para construir un sistema completo de retail con IA agéntica e inventario en tiempo real.

## 🎯 Descripción General

Este repositorio contiene tres laboratorios secuenciales que construyen **Voltia**, una tienda de electrónica con:
- **Pipeline de inventario en tiempo real** usando Confluent Kafka y ksqlDB
- **Sistema multi-agente de IA** con watsonx Orchestrate para asistencia de compra
- **Frontend web moderno** en React con asistente conversacional embebido

## 📚 Estructura de Laboratorios

### Lab 1 - Pipeline de Inventario con Confluent Kafka
Construye la capa de datos operacionales en tiempo real:
- Creación de tópicos Kafka para transacciones de inventario
- Procesamiento de streams con ksqlDB
- Cálculo automático de disponibilidad por sucursal

**Tutorial:** [`Lab1/tutorial.md`](Lab1/tutorial.md)

### Lab 2 - IA Agéntica con watsonx Orchestrate
Desarrolla un sistema multi-agente que consulta inventario en tiempo real:
- **SKU Availability Agent**: consulta stock usando herramienta MCP conectada a Kafka
- **Substitute Finder Agent**: recomienda alternativas usando RAG sobre catálogo de productos
- **Store Associate Agent**: supervisor que coordina agentes especializados
- **Customer Shopping Assistant**: asistente conversacional para clientes finales

**Tutorial:** [`Lab2/tutorial.md`](Lab2/tutorial.md)

### Lab 3 - Frontend Web con React (Voltia)
Construye la tienda web completa con asistente embebido:
- Storefront con filtros y catálogo de productos
- Páginas de detalle con disponibilidad por sucursal
- Sistema de reserva para retiro en tienda
- Integración del asistente de watsonx Orchestrate
- Animaciones con Framer Motion
- Documentación con MkDocs

**Tutorial:** [`Lab3/tutorial.md`](Lab3/tutorial.md)


## 📁 Estructura del Proyecto

```
Labs-tech-summit/
├── .env.example                    # Plantilla de configuración
├── README.md                       # Este archivo
├── Lab1/                           # Pipeline de inventario
│   ├── tutorial.md
│   └── inventory-pipeline/
│       ├── setup.sh               # Script automatizado (Linux/Mac)
│       ├── setup.ps1              # Script automatizado (Windows)
│       └── *.py                   # Scripts Python para Kafka
├── Lab2/                           # IA Agéntica
│   ├── tutorial.md
│   ├── README.md
│   └── confluent_agents/
│       ├── *.yaml                 # Definiciones de agentes
│       ├── get_sku_availability.py # Herramienta MCP
│       └── product-catalog.docx   # Base de conocimiento RAG
└── Lab3/                           # Frontend Voltia
    ├── tutorial.md
    └── voltia-starter/
        ├── src/                   # Código React
        ├── docs/                  # Documentación MkDocs
        └── mockups/               # Diseños de referencia
```