/** @type {import('tailwindcss').Config} */
// The Bob's Beans design tokens — the colors used in the mockups (mockups/*.png).
// Use these names in your classes so the screens you build match the design —
// e.g. bg-cream, text-ink, bg-coffee, text-caramel.
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        espresso: "#4e3526", // darkest brown — hero gradient, dark text
        coffee: "#6f4e37", // brand brown — primary buttons, active states
        "coffee-dark": "#4e3526", // button hover
        ink: "#2a2118", // near-black text / footer
        muted: "#8a7a6d", // secondary text
        cream: "#faf6f0", // page background
        latte: "#e8ddcf", // soft fill / chips
        line: "#e7ddd0", // borders
        caramel: "#c9742f", // accent — sale tags, cart badge, ratings
        success: "#4c7a34" // in-stock green
      },
      borderRadius: {
        card: "14px"
      },
      boxShadow: {
        card: "0 1px 2px rgba(58,36,23,.06), 0 8px 22px rgba(58,36,23,.08)"
      },
      fontFamily: {
        sans: [
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "Roboto",
          "Helvetica",
          "Arial",
          "sans-serif"
        ]
      },
      maxWidth: {
        page: "1200px"
      }
    }
  },
  plugins: []
};
