# Lab 2 — Agentes retail con watsonx Orchestrate

El Lab 2 usa un MCP remoto compartido que expone la tool `get_sku_availability`.
El MCP se encarga de acceder a Kafka/ksqlDB en la VM del workshop; no instales
ni ejecutes un servidor MCP local.

## Participante

Desde esta carpeta:

```bash
cd Lab2/confluent_agents
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install ibm-watsonx-orchestrate
orchestrate --version

cp workshop-config.env.example workshop-config.env
# Completa las URLs entregadas por el facilitador y carga la configuración.
source workshop-config.env

orchestrate env add --name workshop --url "$ORCHESTRATE_URL"
orchestrate env activate workshop --api-key "<Orchestrate API Key>"
orchestrate toolkits list
```

El toolkit `retail_availability_mcp` debe aparecer con
`get_sku_availability`. Si no aparece, avisa al facilitador y no ejecutes
`orchestrate toolkits add`.

Importa los agentes en este orden:

```bash
orchestrate agents import --file SKU_Availability_Agent.yaml
orchestrate agents import --file Substitute_Finder_Agent.yaml
orchestrate agents import --file Store_Associate_Agent.yaml
orchestrate agents import --file Customer_Shopping_Assistant.yaml
orchestrate agents list
```

Después despliega cada agente en la UI de watsonx Orchestrate y configura
`enterprise_documents` para los agentes que usan el catálogo.

## Facilitador

Completa `workshop-config.env` con la URL SSE del MCP y ejecuta una sola vez:

```bash
./register_shared_toolkit.sh
```

El script registra `retail_availability_mcp` con transporte SSE y la tool
`get_sku_availability`. No contiene credenciales de Kafka ni de Orchestrate.
