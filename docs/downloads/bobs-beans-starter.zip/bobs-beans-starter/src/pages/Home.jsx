// ═══════════════════════════════════════════════════════════════════════════
//  LAB 02 — Build the storefront.   Make this page match  mockups/home.png
//
//  What this page should do:
//    • Fetch the catalog with  getProducts()  from ../api/client
//    • Show the hero banner, the category filter chips, and a responsive grid
//      of <ProductCard /> (you'll build ProductCard.jsx in this same lab)
//    • Each product card links to  /product/:id
//
//  Tokens are ready in tailwind.config.js — use bg-coffee, bg-cream, text-ink,
//  text-caramel, shadow-card, rounded-card, etc. so it matches the design.
//
//  Do NOT edit ../api/client.js, and do NOT add new dependencies.
//  Delete this placeholder once you start building.
// ═══════════════════════════════════════════════════════════════════════════

export default function Home() {
  return <BuildMePlaceholder />;
}

function BuildMePlaceholder() {
  return (
    <div className="page-wrap py-20">
      <div className="mx-auto max-w-xl rounded-card border border-dashed border-line bg-white p-10 text-center shadow-card">
        <div className="text-5xl">🚧</div>
        <h1 className="mt-4 text-2xl font-extrabold text-ink">Storefront — build me in Lab 02</h1>
        <p className="mt-3 text-muted">
          Open <code className="rounded bg-latte px-1.5 py-0.5 text-ink">mockups/home.png</code> and ask Bob to
          implement this page: hero, category chips, and a product grid powered by{" "}
          <code className="rounded bg-latte px-1.5 py-0.5 text-ink">getProducts()</code>.
        </p>
        <p className="mt-4 text-sm text-muted">
          The header, footer, cart, routing, and API client are already wired — you only build the screens.
        </p>
      </div>
    </div>
  );
}
