// ─────────────────────────────────────────────────────────────────────────
//  Toast notifications  —  PRE-WIRED state. Use it anywhere:
//
//      import { useToast } from "../toast/ToastContext";
//      const { notify } = useToast();
//      notify("Added to cart");        // shows a small toast for ~2.5s
//
//  The toast that renders here is intentionally PLAIN. In Lab 05 you'll make it
//  spring in with an animation — that's the one part of this file you'll edit.
// ─────────────────────────────────────────────────────────────────────────

import { createContext, useCallback, useContext, useRef, useState } from "react";

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const idRef = useRef(0);

  const notify = useCallback((message) => {
    const id = ++idRef.current;
    setToasts((current) => [...current, { id, message }]);
    setTimeout(() => {
      setToasts((current) => current.filter((t) => t.id !== id));
    }, 2500);
  }, []);

  return (
    <ToastContext.Provider value={{ notify }}>
      {children}

      {/* Lab 05: animate this list (e.g. framer-motion AnimatePresence + motion.div). */}
      <div className="pointer-events-none fixed bottom-6 right-6 z-50 flex flex-col gap-2">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="pointer-events-auto flex items-center gap-2 rounded-full bg-ink px-5 py-3 text-sm font-semibold text-white shadow-card"
          >
            <span className="text-success">✓</span>
            {toast.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside <ToastProvider>");
  return ctx;
}
