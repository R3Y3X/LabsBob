# Labs Tech Summit

Laboratorios prácticos que integran **Confluent Kafka**, **IBM watsonx Orchestrate** y **React** para construir un sistema completo de retail con IA agéntica e inventario en tiempo real.

## 🎯 Descripción General

Este repositorio contiene tres laboratorios secuenciales que construyen **Voltia**, una tienda de electrónica con:
- **Pipeline de inventario en tiempo real** usando Confluent Kafka y ksqlDB
- **Sistema multi-agente de IA** con watsonx Orchestrate para asistencia de compra
- **Frontend web moderno** en React con asistente conversacional embebido

## 📚 Estructura de Laboratorios

### Track D - Pipeline de Inventario con Confluent Kafka
Construye la capa de datos operacionales en tiempo real:
- Creación de tópicos Kafka para transacciones de inventario
- Procesamiento de streams con ksqlDB
- Cálculo automático de disponibilidad por sucursal

**Tutorial:** [`trackD/tutorial.md`](trackD/tutorial.md)

### Track F - IA Agéntica con watsonx Orchestrate
Desarrolla un sistema multi-agente que consulta inventario en tiempo real mediante un MCP remoto compartido:
- **SKU Availability Agent**: consulta stock usando herramienta MCP conectada a Kafka
- **Substitute Finder Agent**: recomienda alternativas usando RAG sobre catálogo de productos
- **Store Associate Agent**: supervisor que coordina agentes especializados
- **Customer Shopping Assistant**: asistente conversacional para clientes finales

**Guía:** [`trackF/README.md`](trackF/README.md)

### Voltia - Frontend Web con React (Voltia)
Construye la tienda web completa con asistente embebido:
- Storefront con filtros y catálogo de productos
- Páginas de detalle con disponibilidad por sucursal
- Sistema de reserva para retiro en tienda
- Integración del asistente de watsonx Orchestrate
- Animaciones con Framer Motion
- Documentación con MkDocs

**Tutorial:** [`voltia/tutorial.md`](voltia/tutorial.md)


## 📁 Estructura del Proyecto

```
RoadShowBobStreamingIntegration/
├── .env.example                    # Configuración del pipeline Track D
├── README.md                       # Este archivo
├── trackD/                           # Pipeline de inventario
│   ├── README.md
│   └── inventory-pipeline/
│       ├── setup.sh               # Script automatizado (Linux/Mac)
│       ├── setup.ps1              # Script automatizado (Windows)
│       └── *.py                   # Scripts Python para Kafka
├── trackF/                           # IA Agéntica
│   ├── tutorial.md
│   ├── README.md
│   └── confluent_agents/
│       ├── *.yaml                 # Definiciones de agentes
│       ├── workshop-config.env.example # Configuración sin secretos
│       ├── register_shared_toolkit.sh  # Registro para el facilitador
│       └── product-catalog.docx   # Base de conocimiento RAG
└── voltia/                           # Frontend Voltia
    ├── tutorial.md
    └── voltia-starter/
        ├── src/                   # Código React
        ├── docs/                  # Documentación MkDocs
        └── mockups/               # Diseños de referencia
```

El toolkit MCP se registra una sola vez por instancia de watsonx Orchestrate.
Los participantes solo preparan la CLI, activan su ambiente, verifican
`retail_availability_mcp` e importan los cuatro YAML en este orden:

1. `SKU_Availability_Agent.yaml`
2. `Substitute_Finder_Agent.yaml`
3. `Store_Associate_Agent.yaml`
4. `Customer_Shopping_Assistant.yaml`
