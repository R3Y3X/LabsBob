# Track F — Agentes retail con watsonx Orchestrate

El Track F usa un MCP remoto compartido que expone la tool `get_sku_availability`.
El MCP se encarga de acceder a Kafka/ksqlDB en la VM del workshop; no instales
ni ejecutes un servidor MCP local.

## Participante

**No escribes comandos.** Abre la carpeta `trackF/confluent_agents` en IBM Bob
(File → Open Folder), pon a Bob en **Agent Mode** y pégale estos prompts en
orden, todos en la misma conversación.

### 1. Preparar la CLI

```
Estoy en la carpeta trackF/confluent_agents de un workshop de watsonx Orchestrate.
Prepara mi entorno de trabajo usando la terminal integrada:

1. Crea un entorno virtual de Python llamado .venv en esta carpeta.
2. Actívalo. Si estoy en Windows, usa .venv\Scripts\Activate.ps1 en vez de source.
3. Con el entorno activo, actualiza pip.
4. Instala el paquete ibm-watsonx-orchestrate.
5. Ejecuta "orchestrate --version" y dime qué versión quedó instalada.

Mantén esta misma terminal para todo el laboratorio. Si algún paso falla,
detente ahí y explícame el error.
```

### 2. Preparar la configuración

```
Copia workshop-config.env.example a workshop-config.env. No edites el .example.
Muéstrame el contenido y dime qué variables tengo que completar yo.
No inventes URLs ni claves: espera a que yo complete el archivo.
```

Después completa tú mismo en `workshop-config.env`:

- `ORCHESTRATE_URL` — URL de tu instancia.
- `RETAIL_MCP_SSE_URL` — endpoint SSE del MCP compartido.
- `ORCHESTRATE_API_KEY` — tu API key. Vive solo en este archivo local.

### 3. Activar el ambiente y verificar el toolkit

```
Ya completé workshop-config.env. Sigue en la misma terminal:

1. Carga las variables con: source workshop-config.env
2. Registra el ambiente:
   orchestrate env add --name workshop --url "$ORCHESTRATE_URL"
   Si "workshop" ya existe, salta este comando.
3. Actívalo usando la variable, nunca el valor literal:
   orchestrate env activate workshop --api-key "$ORCHESTRATE_API_KEY"
4. Ejecuta: orchestrate toolkits list

No imprimas el valor de ORCHESTRATE_API_KEY en pantalla ni en tu resumen.
Dime si aparece el toolkit "retail_availability_mcp" con la tool
"get_sku_availability". Si NO aparece, detente y avísame: no ejecutes
"orchestrate toolkits add" bajo ninguna circunstancia.
```

### 4. Importar los agentes, uno por fase

El orden importa: `Store_Associate_Agent` declara como colaboradores a los dos
primeros y su import falla si faltan.

```
Importa SKU_Availability_Agent.yaml y confirma con "orchestrate agents list".
No importes todavía ningún otro YAML.
```

```
Importa Substitute_Finder_Agent.yaml y confirma que ahora son dos agentes.
```

```
Verifica primero con "orchestrate agents list" que existan
SKU_Availability_Agent y Substitute_Finder_Agent. Si ambos están, importa
Store_Associate_Agent.yaml. Si falta alguno, NO importes: dime cuál falta.
```

```
Importa Customer_Shopping_Assistant.yaml y confirma que aparecen los cuatro
agentes.
```

### 5. En la UI de watsonx Orchestrate

Al terminar cada import, entra a tu instancia y prueba el agente antes de
seguir:

| Agente | Configuración en la UI | Pregunta de prueba |
| --- | --- | --- |
| `SKU_Availability_Agent` | Deploy | ¿Cuánto stock hay de LAPTOP-DELL-XPS-15 en DOT Shopping? |
| `Substitute_Finder_Agent` | Knowledge → subir `product-catalog.docx` como `enterprise_documents` → Deploy | LAPTOP-DELL-XPS-15 no está disponible. Sugiere una laptop similar usando el catálogo. |
| `Store_Associate_Agent` | Verificar colaboradores → Deploy | ¿Tienes LAPTOP-MACBOOK-PRO-16 en Unicenter? |
| `Customer_Shopping_Assistant` | Knowledge → `enterprise_documents` · Toolset → `get_sku_availability` → Deploy | Busco una laptop para trabajo y edición de fotos en Unicenter. ¿Qué me recomiendas con stock? |

El snippet embebible del asistente está en **Channels → Embedded agent → Live**.
Guárdalo para el Voltia.

## Facilitador

Completa `workshop-config.env` con la URL SSE del MCP y ejecuta una sola vez:

```bash
./register_shared_toolkit.sh
```

El script registra `retail_availability_mcp` con transporte SSE y la tool
`get_sku_availability`. No contiene credenciales de Kafka ni de Orchestrate.
