# Bob's Beans — Storefront Starter

The starter project for the **Software Development Lifecycle** workshop. It is a
**ready-to-run** React + Vite + Tailwind app. The shell is already built — during
the labs you fill in the screens and then polish them.

## Run it

```bash
npm install
```

```bash
cp .env.example .env
```

Set `VITE_API_BASE_URL` in `.env` to your instructor's API URL, then:

```bash
npm run dev
```

You should see the Bob's Beans header, footer, and three "🚧 build me" placeholder
pages at `/`, `/product/:id`, and `/cart`. That means everything is wired correctly.

## What's already done (don't edit these)

| File | What it gives you |
|---|---|
| `src/api/client.js` | `getProducts()`, `getProduct(id)`, `getCategories()`, `createOrder()`, `imageUrl()` — pre-wired to the API. |
| `src/cart/CartContext.jsx` | Global cart via `useCart()` — `addItem`, `setQty`, `removeItem`, `clear`, `count`, `subtotal`. |
| `src/toast/ToastContext.jsx` | Toast notifications via `useToast().notify("…")`. |
| `src/components/Header.jsx` | Header with the live cart badge. |
| `src/components/Footer.jsx` | Footer. |
| `src/App.jsx`, `src/main.jsx` | Routing (`/`, `/product/:id`, `/cart`) + providers. |
| `tailwind.config.js` | The coffee design tokens: `coffee`, `espresso`, `cream`, `latte`, `caramel`, `ink`, `muted`, `line`, `success`. |

`framer-motion` is already installed for the animations lab.

## What you build (per lab)

| Lab | File(s) | Reference |
|---|---|---|
| **02** | `src/pages/Home.jsx`, `src/components/ProductCard.jsx` | `mockups/home.png` |
| **03** | `src/pages/Product.jsx` | `mockups/product.png` |
| **04** | `src/pages/Cart.jsx` | `mockups/cart.png` |
| **05** | add motion across the screens (incl. `ToastContext.jsx`, `Header.jsx`) | — |
| **06** | review & polish all three screens against the mockups | the mockups |
| **07** | generate a `docs/` site for the app | — |

Each page stub has a comment block telling you exactly what to build, which client
function to call, and which mockup to match.

## The mockups

`mockups/` contains the three screenshots (`home.png`, `product.png`, `cart.png`) plus the
matching design-spec HTML (`*.mockup.html`) — the HTML spells out every color and size if
you want the exact detail. Attach the relevant screenshot to Bob's chat for each build lab.

## Scope — what we are NOT building

✅ Consume the provided API · client-side cart · checkout that always confirms
❌ No backend · no accounts/login · no payment · no pagination/wishlist/admin

Stay inside the screens and the existing files. That's the whole point.
