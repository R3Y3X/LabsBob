// Site header — PRE-BUILT and matches the mockups. The cart badge is already
// wired to the live cart count. You shouldn't need to change this file
// (in Lab 05 you'll add a little animation to the badge).
import { Link } from "react-router-dom";
import { useCart } from "../cart/CartContext";

export default function Header() {
  const { count } = useCart();

  return (
    <header className="sticky top-0 z-10 border-b border-line bg-white">
      <div className="page-wrap flex h-[74px] items-center">
        <Link to="/" className="flex items-center gap-2.5 text-[22px] font-extrabold tracking-tight">
          <span className="flex h-[34px] w-[34px] items-center justify-center rounded-[10px] bg-coffee text-lg text-white">
            ☕
          </span>
          Bob&apos;s Beans
        </Link>

        <Link
          to="/cart"
          className="relative ml-auto flex h-11 w-11 items-center justify-center rounded-full border border-line bg-white text-xl"
          aria-label={`Cart, ${count} item${count === 1 ? "" : "s"}`}
        >
          🛒
          {count > 0 && (
            <span className="absolute -right-1.5 -top-1.5 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-caramel px-1.5 text-xs font-bold text-white">
              {count}
            </span>
          )}
        </Link>
      </div>
    </header>
  );
}
