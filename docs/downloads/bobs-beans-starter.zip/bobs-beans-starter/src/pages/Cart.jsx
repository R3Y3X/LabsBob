// ═══════════════════════════════════════════════════════════════════════════
//  LAB 04 — Build the cart & checkout.   Match  mockups/cart.png
//
//  What this page should do:
//    • Read the cart from  useCart()  — { items, subtotal, setQty, removeItem, clear }
//    • List each line (image, name, unit price, quantity stepper, line total, remove)
//    • Show an order-summary card: subtotal, free shipping, estimated tax, total
//    • "Place order" calls  createOrder({ items })  from ../api/client, then shows
//      a confirmation (the API returns an orderId) and calls  clear()
//    • Handle the empty-cart state too
//
//  Do NOT edit ../api/client.js. Delete this placeholder once you start.
// ═══════════════════════════════════════════════════════════════════════════

import { useCart } from "../cart/CartContext";

export default function Cart() {
  const { count } = useCart();
  return (
    <div className="page-wrap py-20">
      <div className="mx-auto max-w-xl rounded-card border border-dashed border-line bg-white p-10 text-center shadow-card">
        <div className="text-5xl">🚧</div>
        <h1 className="mt-4 text-2xl font-extrabold text-ink">Cart &amp; checkout — build me in Lab 04</h1>
        <p className="mt-3 text-muted">
          The cart currently holds <strong className="text-ink">{count}</strong> item(s). Build the line items and
          summary to match <code className="rounded bg-latte px-1.5 py-0.5 text-ink">mockups/cart.png</code>, and
          wire "Place order" to <code className="rounded bg-latte px-1.5 py-0.5 text-ink">createOrder()</code>.
        </p>
      </div>
    </div>
  );
}
