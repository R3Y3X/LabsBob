#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="${1:-${SCRIPT_DIR}/workshop-config.env}"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "No existe ${CONFIG_FILE}. Copia workshop-config.env.example y completa RETAIL_MCP_SSE_URL." >&2
  exit 1
fi

# shellcheck disable=SC1090
source "${CONFIG_FILE}"
: "${RETAIL_MCP_SSE_URL:?Falta RETAIL_MCP_SSE_URL}"
: "${RETAIL_MCP_TOOLKIT_NAME:?Falta RETAIL_MCP_TOOLKIT_NAME}"

echo "Registrando toolkit ${RETAIL_MCP_TOOLKIT_NAME} → ${RETAIL_MCP_SSE_URL}"
orchestrate toolkits add \
  --kind mcp \
  --name "${RETAIL_MCP_TOOLKIT_NAME}" \
  --description "MCP retail compartido — disponibilidad de inventario en tiempo real" \
  --url "${RETAIL_MCP_SSE_URL}" \
  --transport sse \
  --tools "get_sku_availability"

orchestrate toolkits list
