// ─────────────────────────────────────────────────────────────────────────
//  Bob's Beans API client  —  PRE-WIRED. You should NOT need to edit this file.
//
//  Every screen talks to the backend ONLY through the functions below. They
//  default to the hosted Bob's Beans API; override it with VITE_API_BASE_URL in
//  your .env if you're running the API yourself. Just import what you need:
//
//      import { getProducts, getProduct, createOrder, imageUrl } from "../api/client";
//
//  If a call fails, these throw an Error with a readable message — let the
//  page catch it and show a friendly state.
// ─────────────────────────────────────────────────────────────────────────

const BASE_URL =
  import.meta.env.VITE_API_BASE_URL ||
  "https://bobs-beans-api.2akfv5yaq586.us-south.codeengine.appdomain.cloud";

/**
 * @typedef {Object} Product
 * @property {string}   id
 * @property {string}   name
 * @property {string}   category          One of: Single Origin, Blends, Decaf, Equipment
 * @property {number}   price             Whole dollars, e.g. 19
 * @property {string}   image             Relative path — wrap with imageUrl()
 * @property {string}   shortDescription
 * @property {string}   longDescription
 * @property {string|null} roast          e.g. "Light" (null for Equipment)
 * @property {string}   origin
 * @property {string}   weight
 * @property {string[]} tastingNotes
 * @property {number}   rating            0–5
 * @property {number}   reviewCount
 * @property {boolean}  inStock
 * @property {boolean}  featured
 */

/**
 * @typedef {Object} OrderConfirmation
 * @property {string} orderId
 * @property {string} status              Always "confirmed"
 * @property {Array}  items
 * @property {number} subtotal
 * @property {number} shipping
 * @property {number} tax
 * @property {number} total
 * @property {string} estimatedDelivery
 * @property {string} createdAt
 */

async function request(path, options) {
  let res;
  try {
    res = await fetch(`${BASE_URL}${path}`, options);
  } catch (networkError) {
    throw new Error(
      `Could not reach the API at ${BASE_URL}. Is it running, and is VITE_API_BASE_URL correct in your .env?`
    );
  }
  if (!res.ok) {
    throw new Error(`API request to ${path} failed with status ${res.status}`);
  }
  return res.json();
}

/**
 * Fetch the product catalog. Optionally filter by category and/or search term.
 * @param {{ category?: string, search?: string }} [opts]
 * @returns {Promise<Product[]>}
 */
export function getProducts(opts = {}) {
  const params = new URLSearchParams();
  if (opts.category && opts.category !== "All") params.set("category", opts.category);
  if (opts.search) params.set("search", opts.search);
  const qs = params.toString();
  return request(`/api/products${qs ? `?${qs}` : ""}`);
}

/**
 * Fetch a single product by id.
 * @param {string} id
 * @returns {Promise<Product>}
 */
export function getProduct(id) {
  return request(`/api/products/${id}`);
}

/**
 * Fetch the list of category names.
 * @returns {Promise<string[]>}
 */
export function getCategories() {
  return request(`/api/categories`);
}

/**
 * Place an order. The API ALWAYS confirms — no payment, no accounts.
 * @param {{ items: Array<{ id: string, quantity: number }> }} order
 * @returns {Promise<OrderConfirmation>}
 */
export function createOrder(order) {
  return request(`/api/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(order)
  });
}

/**
 * Turn a product's relative `image` path into a full URL you can put in <img src>.
 * @param {string} path  e.g. product.image
 * @returns {string}
 */
export function imageUrl(path) {
  if (!path) return "";
  return path.startsWith("http") ? path : `${BASE_URL}${path}`;
}
