// ═══════════════════════════════════════════════════════════════════════════
//  LAB 03 — Build the product detail page.   Match  mockups/product.png
//
//  What this page should do:
//    • Read the :id from the URL with  useParams()  (react-router-dom)
//    • Fetch that product with  getProduct(id)  from ../api/client
//    • Show the image, category, name, rating, price, description, tasting-note
//      chips, a quantity stepper, and an "Add to cart" button
//    • "Add to cart" calls  addItem(product, qty)  from  useCart()
//
//  Use  imageUrl(product.image)  for the <img> src.
//  Do NOT edit ../api/client.js. Delete this placeholder once you start.
// ═══════════════════════════════════════════════════════════════════════════

import { useParams } from "react-router-dom";

export default function Product() {
  const { id } = useParams();
  return (
    <div className="page-wrap py-20">
      <div className="mx-auto max-w-xl rounded-card border border-dashed border-line bg-white p-10 text-center shadow-card">
        <div className="text-5xl">🚧</div>
        <h1 className="mt-4 text-2xl font-extrabold text-ink">Product detail — build me in Lab 03</h1>
        <p className="mt-3 text-muted">
          URL param <code className="rounded bg-latte px-1.5 py-0.5 text-ink">id = {id}</code> — fetch it with{" "}
          <code className="rounded bg-latte px-1.5 py-0.5 text-ink">getProduct(id)</code> and match{" "}
          <code className="rounded bg-latte px-1.5 py-0.5 text-ink">mockups/product.png</code>.
        </p>
      </div>
    </div>
  );
}
