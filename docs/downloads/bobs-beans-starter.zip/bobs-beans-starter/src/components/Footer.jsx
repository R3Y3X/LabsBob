// Site footer — PRE-BUILT and matches the mockups. No need to change this file.
export default function Footer() {
  return (
    <footer className="mt-auto bg-ink py-10 text-[#cdbfb0]">
      <div className="page-wrap flex items-center justify-between text-sm">
        <div className="text-lg font-extrabold text-white">☕ Bob&apos;s Beans</div>
        <div>© 2026 Bob&apos;s Beans · Built in the IBM Bob SDLC workshop</div>
      </div>
    </footer>
  );
}
