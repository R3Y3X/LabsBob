# Este proyecto es el material del workshop "¿Tu código es seguro?"

Las instrucciones completas (Rules, Auditoría ASVS, Código seguro
actor-critic) están en el sitio del workshop, no en este README — el
`README.md` de al lado es el de Galaxium Travels como proyecto en sí.

Este zip contiene solo esta carpeta: descomprímelo y abre `galaxium-travels/`
directamente como raíz del proyecto en IBM Bob. Es el workspace de los tres
labs del workshop.
