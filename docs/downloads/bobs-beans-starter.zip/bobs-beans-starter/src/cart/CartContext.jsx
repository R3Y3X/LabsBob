// ─────────────────────────────────────────────────────────────────────────
//  Global cart state  —  PRE-WIRED. You should NOT need to edit this file.
//
//  Anywhere in the app:
//
//      import { useCart } from "../cart/CartContext";
//      const { items, count, subtotal, addItem, setQty, removeItem, clear } = useCart();
//
//      addItem(product, 1)   // add (or increment) a product
//      setQty(id, 3)         // set an exact quantity (removes if <= 0)
//      removeItem(id)        // remove a line
//      clear()               // empty the cart (call after a successful order)
//
//  Each cart line looks like: { id, name, price, image, category, quantity }
//  The cart is saved to localStorage so it survives a page refresh.
// ─────────────────────────────────────────────────────────────────────────

import { createContext, useContext, useEffect, useMemo, useState } from "react";

const CartContext = createContext(null);
const STORAGE_KEY = "bobs-beans-cart";

function loadInitial() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function CartProvider({ children }) {
  const [items, setItems] = useState(loadInitial);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* ignore quota / private-mode errors */
    }
  }, [items]);

  function addItem(product, quantity = 1) {
    setItems((prev) => {
      const existing = prev.find((line) => line.id === product.id);
      if (existing) {
        return prev.map((line) =>
          line.id === product.id ? { ...line, quantity: line.quantity + quantity } : line
        );
      }
      return [
        ...prev,
        {
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image,
          category: product.category,
          quantity
        }
      ];
    });
  }

  function setQty(id, quantity) {
    setItems((prev) =>
      quantity <= 0
        ? prev.filter((line) => line.id !== id)
        : prev.map((line) => (line.id === id ? { ...line, quantity } : line))
    );
  }

  function removeItem(id) {
    setItems((prev) => prev.filter((line) => line.id !== id));
  }

  function clear() {
    setItems([]);
  }

  const { count, subtotal } = useMemo(() => {
    return items.reduce(
      (acc, line) => {
        acc.count += line.quantity;
        acc.subtotal += line.price * line.quantity;
        return acc;
      },
      { count: 0, subtotal: 0 }
    );
  }, [items]);

  const value = { items, count, subtotal, addItem, setQty, removeItem, clear };
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
  return ctx;
}
